// NUH Component Showcase Section

window.NUHComponentShowcase = function NUHComponentShowcase() {
  return (
    <section style={{ display:'flex', flexDirection:'column', gap:16 }}>
      <h2 style={{ fontSize:24, fontWeight:600, letterSpacing:'-0.02em', color:'var(--foreground)', margin:0 }}>
        Component Showcase
      </h2>
      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:12 }}>
        <ShowcaseCard title="Buttons" desc="Primary and secondary actions">
          <div style={{ display:'flex', flexWrap:'wrap', gap:8 }}>
            {[
              { label:'Primary', bg:'oklch(0.319 0.117 258)', color:'white', border:'none' },
              { label:'Secondary', bg:'var(--secondary)', color:'var(--foreground)', border:'none' },
              { label:'Outline', bg:'transparent', color:'var(--foreground)', border:'1px solid var(--border)' },
              { label:'Ghost', bg:'transparent', color:'var(--foreground)', border:'none' },
              { label:'Destructive', bg:'oklch(0.579 0.234 24)', color:'white', border:'none' },
            ].map(b => (
              <button key={b.label} style={{
                background: b.bg, color: b.color, border: b.border || 'none',
                fontFamily:'var(--font-sans)', fontSize:13, fontWeight:500,
                padding:'7px 14px', borderRadius:'var(--radius-md)', cursor:'pointer',
                transition:'opacity 0.15s',
              }}
              onMouseEnter={e => e.currentTarget.style.opacity='0.8'}
              onMouseLeave={e => e.currentTarget.style.opacity='1'}
              >{b.label}</button>
            ))}
          </div>
        </ShowcaseCard>

        <ShowcaseCard title="Badges" desc="Labels and status indicators">
          <div style={{ display:'flex', flexWrap:'wrap', gap:8, alignItems:'center' }}>
            {[
              { label:'Default', bg:'oklch(0.319 0.117 258)', color:'white', border:'none' },
              { label:'Secondary', bg:'var(--secondary)', color:'var(--foreground)', border:'none' },
              { label:'Outline', bg:'transparent', color:'var(--foreground)', border:'1px solid var(--border)' },
              { label:'Destructive', bg:'oklch(0.579 0.234 24)', color:'white', border:'none' },
              { label:'Info', bg:'oklch(0.625 0.145 243)', color:'white', border:'none' },
            ].map(b => (
              <span key={b.label} style={{
                display:'inline-flex', alignItems:'center',
                borderRadius:9999, padding:'2px 10px',
                fontSize:11, fontWeight:500,
                background: b.bg, color: b.color, border: b.border || 'none',
              }}>{b.label}</span>
            ))}
          </div>
        </ShowcaseCard>

        <ShowcaseCard title="Typography" desc="Foreground and muted text">
          <div style={{ display:'flex', flexDirection:'column', gap:6 }}>
            <p style={{ margin:0, fontSize:14, fontWeight:600, color:'var(--foreground)' }}>Foreground — primary text</p>
            <p style={{ margin:0, fontSize:14, color:'var(--muted-foreground)' }}>Muted foreground — supporting text</p>
            <p style={{ margin:0, fontSize:14, fontWeight:500, color:'oklch(0.674 0.171 53)' }}>Highlight — orange CTAs</p>
            <p style={{ margin:0, fontSize:14, fontWeight:500, color:'oklch(0.625 0.145 243)' }}>Info — light blue links</p>
          </div>
        </ShowcaseCard>

        <ShowcaseCard title="Surfaces" desc="Background and card layers">
          <div style={{ display:'flex', flexDirection:'column', gap:6 }}>
            {[
              { label:'Background', bg:'var(--background)', border:true },
              { label:'Card', bg:'var(--card)', border:true },
              { label:'Muted', bg:'var(--muted)', border:false, color:'var(--muted-foreground)' },
              { label:'Secondary', bg:'var(--secondary)', border:false, color:'var(--secondary-foreground)' },
            ].map(s => (
              <div key={s.label} style={{
                background:s.bg, borderRadius:'var(--radius-md)',
                padding:'7px 12px', fontSize:12,
                color: s.color || 'var(--foreground)',
                border: s.border ? '1px solid var(--border)' : 'none',
              }}>{s.label}</div>
            ))}
          </div>
        </ShowcaseCard>
      </div>
    </section>
  );
};

function ShowcaseCard({ title, desc, children }) {
  return (
    <div style={{
      background:'var(--card)',
      border:'1px solid var(--border)',
      borderRadius:16,
      padding:'20px 20px',
      boxShadow:'0 1px 3px oklch(0 0 0 / 0.06)',
      display:'flex', flexDirection:'column', gap:12,
    }}>
      <div>
        <div style={{ fontSize:14, fontWeight:600, color:'var(--foreground)', marginBottom:2 }}>{title}</div>
        <div style={{ fontSize:12, color:'var(--muted-foreground)' }}>{desc}</div>
      </div>
      {children}
    </div>
  );
}
