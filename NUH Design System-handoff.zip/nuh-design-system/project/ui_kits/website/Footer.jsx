// NUH Footer Component

window.NUHFooter = function NUHFooter() {
  const links = [
    { label: 'Learn Next.js', href: 'https://nextjs.org/learn' },
    { label: 'shadcn/ui', href: 'https://ui.shadcn.com' },
    { label: 'nuh.com.sg →', href: 'https://www.nuh.com.sg' },
  ];

  return (
    <footer style={{
      borderTop: '1px solid var(--border)',
      marginTop: 16,
      padding: '24px 40px',
      display: 'flex',
      gap: 24,
      flexWrap: 'wrap',
      alignItems: 'center',
      justifyContent: 'center',
    }}>
      {links.map(l => (
        <a key={l.href} href={l.href} target="_blank" rel="noopener" style={{
          fontFamily: 'var(--font-sans)',
          fontSize: 13,
          color: 'var(--muted-foreground)',
          textDecoration: 'none',
          padding: '4px 8px',
          borderRadius: 'var(--radius-md)',
          transition: 'color 0.15s, background 0.15s',
        }}
        onMouseEnter={e => { e.currentTarget.style.color = 'var(--foreground)'; e.currentTarget.style.background = 'var(--muted)'; }}
        onMouseLeave={e => { e.currentTarget.style.color = 'var(--muted-foreground)'; e.currentTarget.style.background = 'none'; }}
        >{l.label}</a>
      ))}
    </footer>
  );
};
