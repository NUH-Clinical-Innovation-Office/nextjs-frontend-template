// NUH Brand Color Palette Section

const COLORS = [
  { name: 'Dark Blue', hex: '#002f6c', oklch: 'oklch(0.319 0.117 258)', desc: 'Primary — main brand color' },
  { name: 'Light Blue', hex: '#178fd7', oklch: 'oklch(0.625 0.145 243)', desc: 'Info — highlights & links' },
  { name: 'Orange', hex: '#e57200', oklch: 'oklch(0.674 0.171 53)', desc: 'Highlight — CTAs & badges' },
  { name: 'Red', hex: '#e4002b', oklch: 'oklch(0.579 0.234 24)', desc: 'Destructive — alerts & warnings' },
];

window.NUHColorPalette = function NUHColorPalette() {
  return (
    <section style={{ display:'flex', flexDirection:'column', gap:16 }}>
      <div>
        <h2 style={{ fontSize:24, fontWeight:600, letterSpacing:'-0.02em', color:'var(--foreground)', margin:'0 0 6px' }}>
          Brand Colour Palette
        </h2>
        <p style={{ fontSize:14, color:'var(--muted-foreground)', margin:0 }}>
          The four NUHS brand colours, applied consistently across light and dark modes.
        </p>
      </div>
      <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:12 }}>
        {COLORS.map(c => (
          <div key={c.hex} style={{
            borderRadius: 16,
            overflow: 'hidden',
            border: '1px solid var(--border)',
            background: 'var(--card)',
            boxShadow: '0 1px 3px oklch(0 0 0 / 0.06)',
          }}>
            <div style={{ background: c.oklch, height: 80, display:'flex', alignItems:'flex-end', padding:'10px 12px' }}>
              <span style={{ fontFamily:'var(--font-mono)', fontSize:11, fontWeight:500, color:'white', opacity:0.9 }}>{c.hex}</span>
            </div>
            <div style={{ padding:'10px 12px' }}>
              <div style={{ fontSize:13, fontWeight:600, color:'var(--foreground)', marginBottom:2 }}>{c.name}</div>
              <div style={{ fontSize:11, color:'var(--muted-foreground)' }}>{c.desc}</div>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};
