// NUH Header Component
// Logo (light/dark aware) + pill mode toggle

window.NUHHeader = function NUHHeader({ dark, onToggleDark }) {
  return (
    <header style={{
      borderBottom: '1px solid var(--border)',
      padding: '14px 40px',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      background: 'var(--background)',
      position: 'sticky',
      top: 0,
      zIndex: 50,
      backdropFilter: 'blur(8px)',
    }}>
      <img
        src={dark ? 'nuh-logo-dark.png' : 'nuh-logo.png'}
        alt="NUH — National University Hospital"
        style={{ height: 36, width: 'auto', display: 'block' }}
        onError={e => { e.target.style.display='none'; }}
      />
      <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
        <nav style={{ display: 'flex', gap: 4 }}>
          {['About', 'Services', 'Research', 'Contact'].map(item => (
            <button key={item} style={{
              background: 'none',
              border: 'none',
              fontFamily: 'var(--font-sans)',
              fontSize: 14,
              fontWeight: 500,
              color: 'var(--muted-foreground)',
              padding: '6px 12px',
              borderRadius: 'var(--radius-md)',
              cursor: 'pointer',
              transition: 'all 0.15s',
            }}
            onMouseEnter={e => { e.target.style.background = 'var(--muted)'; e.target.style.color = 'var(--foreground)'; }}
            onMouseLeave={e => { e.target.style.background = 'none'; e.target.style.color = 'var(--muted-foreground)'; }}
            >{item}</button>
          ))}
        </nav>
        <ModeToggle dark={dark} onToggle={onToggleDark} />
      </div>
    </header>
  );
};

function ModeToggle({ dark, onToggle }) {
  const [pos, setPos] = React.useState(dark ? 24 : 0);
  React.useEffect(() => { setPos(dark ? 24 : 0); }, [dark]);

  return (
    <button
      onClick={onToggle}
      aria-label="Toggle theme"
      style={{
        position: 'relative',
        display: 'flex',
        alignItems: 'center',
        width: 56,
        height: 32,
        borderRadius: 9999,
        border: '1px solid var(--border)',
        background: 'var(--muted)',
        cursor: 'pointer',
        padding: 4,
        outline: 'none',
        transition: 'border-color 0.15s',
      }}
    >
      {/* Sun */}
      <svg style={{ position:'absolute', left:8, width:16, height:16, zIndex:1, opacity: dark ? 0.4 : 1, transition:'opacity 0.15s', color:'var(--foreground)' }} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <circle cx="12" cy="12" r="4"/><line x1="12" y1="2" x2="12" y2="6"/><line x1="12" y1="18" x2="12" y2="22"/><line x1="4.93" y1="4.93" x2="7.76" y2="7.76"/><line x1="16.24" y1="16.24" x2="19.07" y2="19.07"/><line x1="2" y1="12" x2="6" y2="12"/><line x1="18" y1="12" x2="22" y2="12"/><line x1="4.93" y1="19.07" x2="7.76" y2="16.24"/><line x1="16.24" y1="7.76" x2="19.07" y2="4.93"/>
      </svg>
      {/* Moon */}
      <svg style={{ position:'absolute', left:32, width:16, height:16, zIndex:1, opacity: dark ? 1 : 0.4, transition:'opacity 0.15s', color:'var(--foreground)' }} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/>
      </svg>
      {/* Thumb */}
      <div style={{
        position: 'absolute',
        width: 24,
        height: 24,
        borderRadius: 9999,
        background: 'var(--background)',
        boxShadow: '0 1px 3px oklch(0 0 0 / 0.12)',
        transform: `translateX(${dark ? 24 : 0}px)`,
        transition: 'transform 0.2s cubic-bezier(0.4,0,0.2,1)',
        zIndex: 0,
      }} />
    </button>
  );
}
