# NUH Website UI Kit

Recreates the NUH Clinical Innovation Office Next.js frontend template as an interactive click-through prototype.

## Source
- GitHub: `NUH-Clinical-Innovation-Office/nextjs-frontend-template`
- Framework: Next.js 16 · Tailwind CSS 4 · shadcn/ui · Radix UI · Lucide React · Framer Motion

## Files
- `index.html` — Full interactive prototype (light/dark, all screens)
- `Header.jsx` — Site header with logo + mode toggle
- `HeroSection.jsx` — Hero / landing area with badge, headline, CTAs
- `ColorPalette.jsx` — Brand color showcase section
- `ComponentShowcase.jsx` — Button/badge/typography/surface grid
- `Footer.jsx` — Site footer with links

## Design notes
- Modern, rounded aesthetic — less boxy than default shadcn
- Full light/dark mode support
- Lucide icons via CDN
- Fonts: DM Sans (Geist substitute) from Google Fonts
