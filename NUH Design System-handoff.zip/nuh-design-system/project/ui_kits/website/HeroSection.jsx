// NUH Hero Section

window.NUHHero = function NUHHero() {
  return (
    <section style={{ display:'flex', flexDirection:'column', gap:20, padding:'64px 0 48px' }}>
      {/* Badge */}
      <div>
        <span style={{
          display: 'inline-flex',
          alignItems: 'center',
          borderRadius: 9999,
          border: '1px solid var(--border)',
          padding: '3px 12px',
          fontSize: 12,
          fontWeight: 500,
          color: 'var(--foreground)',
          background: 'transparent',
        }}>Frontend Template</span>
      </div>

      {/* Headline */}
      <h1 style={{
        fontSize: 44,
        fontWeight: 700,
        letterSpacing: '-0.025em',
        color: 'var(--foreground)',
        lineHeight: 1.1,
        margin: 0,
        maxWidth: 640,
      }}>
        National University<br/>Hospital
      </h1>

      {/* Description */}
      <p style={{
        fontSize: 18,
        color: 'var(--muted-foreground)',
        maxWidth: 580,
        lineHeight: 1.65,
        margin: 0,
      }}>
        A Next.js frontend template styled with the NUH brand identity — ready for building
        internal tools and patient-facing applications.
      </p>

      {/* CTAs */}
      <div style={{ display:'flex', gap:10, flexWrap:'wrap', marginTop:4 }}>
        <a href="https://www.nuh.com.sg" target="_blank" rel="noopener" style={{
          display: 'inline-flex',
          alignItems: 'center',
          gap: 6,
          background: 'oklch(0.319 0.117 258)',
          color: 'white',
          borderRadius: 'var(--radius-md)',
          padding: '10px 22px',
          fontSize: 14,
          fontWeight: 500,
          textDecoration: 'none',
          transition: 'background 0.15s',
        }}
        onMouseEnter={e => e.currentTarget.style.background = 'oklch(0.319 0.117 258 / 0.88)'}
        onMouseLeave={e => e.currentTarget.style.background = 'oklch(0.319 0.117 258)'}
        >
          Visit NUH
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>
        </a>
        <a href="https://nextjs.org/docs" target="_blank" rel="noopener" style={{
          display: 'inline-flex',
          alignItems: 'center',
          background: 'transparent',
          color: 'var(--foreground)',
          borderRadius: 'var(--radius-md)',
          padding: '10px 22px',
          fontSize: 14,
          fontWeight: 500,
          textDecoration: 'none',
          border: '1px solid var(--border)',
          transition: 'background 0.15s',
        }}
        onMouseEnter={e => e.currentTarget.style.background = 'var(--muted)'}
        onMouseLeave={e => e.currentTarget.style.background = 'transparent'}
        >
          Read the Next.js docs
        </a>
      </div>
    </section>
  );
};
