# NUH Design System

**National University Hospital (NUH)** — Singapore's leading university hospital, part of the National University Health System (NUHS). NUH is a tertiary hospital serving patients and supporting clinical innovation through its Clinical Innovation Office.

## Sources

- **GitHub Codebase**: `NUH-Clinical-Innovation-Office/nextjs-frontend-template` (Next.js 16, Tailwind CSS 4, shadcn/ui, Radix UI, Lucide React, Framer Motion)
- No Figma link provided. All design tokens were derived from `src/app/globals.css` and component source files.

## Products

- **NUH Website / Clinical Apps** — Patient-facing and internal tools built on the Next.js frontend template. The template is the canonical UI starting point for all Clinical Innovation Office products.

---

## CONTENT FUNDAMENTALS

### Tone & Voice
- **Professional and clinical** but approachable — not cold or bureaucratic.
- Copy is written in **third person for institution references** ("National University Hospital") and **second person for patient-facing CTAs** ("Visit NUH", "Learn more").
- **Title Case** is used for navigation items and section headings (e.g. "Brand Colour Palette", "Component Showcase").
- Sentences are concise — no filler, no jargon overload. e.g. *"A Next.js frontend template styled with the NUH brand identity — ready for building internal tools and patient-facing applications."*
- **British English spelling** is used throughout (e.g. "Colour" not "Color", "Organisation" not "Organization").
- No emoji in UI copy. Emoji are absent from the codebase entirely.
- No first-person "I" — institutional voice throughout.

### Examples
- `"National University Hospital — Singapore's leading university hospital"`
- `"A production-ready template with TypeScript, Tailwind CSS, and comprehensive tooling"`
- `"Highlight — orange CTAs & badges"` (concise semantic descriptions)

---

## VISUAL FOUNDATIONS

### Design Language — v2 (Current)
The current NUH design language has evolved beyond the base shadcn template:
- **Rounder corners**: base radius bumped from 10px → 14px; cards now use 24px (`--radius-2xl`); hero surfaces use 32px (`--radius-3xl`).
- **Less card-heavy**: prefer flat sections with whitespace and subtle dividers over bordered cards. Reserve cards for grouped data, content items, or interactive surfaces — not as a default layout container.
- **Open layouts**: more generous padding, looser type, fewer borders. Use `bg-muted` or no background at all where v1 used `bg-card + border + shadow`.
- **Pills over chips**: full-radius pill shapes for status, filters, and small actions.

### Colors
Four official NUHS brand colors, used strictly:

| Role | Name | Hex | OKLCH |
|------|------|-----|-------|
| Primary | Dark Blue | `#002f6c` | `oklch(0.319 0.117 258)` |
| Info / Links | Light Blue | `#178fd7` | `oklch(0.625 0.145 243)` |
| Highlight / CTAs | Orange | `#e57200` | `oklch(0.674 0.171 53)` |
| Destructive / Alerts | Red | `#e4002b` | `oklch(0.579 0.234 24)` |

**Light mode**: White background (`oklch(1 0 0)`), dark blue foreground. Muted surfaces tinted slightly blue-grey (`oklch(0.96 0.005 258)`).  
**Dark mode**: Near-black background (`oklch(0.2 0 0)`), near-white foreground. Card surfaces at `oklch(0.25 0 0)`. Brand colors remain unchanged in dark mode.

### Typography
- **Primary font**: Geist Sans (Google Fonts) — clean, modern geometric sans-serif
- **Monospace font**: Geist Mono — used for code, hex values, technical labels
- Weights used: 400 (body), 500 (medium), 600 (semibold), 700 (bold)
- Tracking: `tracking-tight` on headings (`letter-spacing: -0.025em`)
- Line heights: standard (`leading-none` for titles, `leading-relaxed` implied for body)

### Spacing & Layout
- Max content width: `max-w-4xl` (896px)
- Section gap: `gap-12` (3rem) between major sections
- Component gap: `gap-4` (1rem) within sections
- Padding: `px-8 py-12` for main content, `px-8 py-4` for header

### Border Radius
- Base: `0.625rem` (10px)
- Small: `calc(0.625rem - 4px)` = 6px
- Medium: `calc(0.625rem - 2px)` = 8px
- Large: `0.625rem` = 10px
- XL: `calc(0.625rem + 4px)` = 14px
- Cards use `rounded-xl` (large), badges use `rounded-full`

### Shadows & Elevation
- Cards: `shadow-sm` (subtle, 1px y-offset)
- Buttons: `shadow-xs` on outline variant
- No heavy drop shadows — elevation is implied via background color layering

### Backgrounds & Surfaces
- No gradients — flat, clean surfaces
- No textures, illustrations, or background images in the base template
- Surface layering: `background → card → popover/muted` in ascending prominence
- Dark mode surfaces are neutral dark grey (not blue-tinted)

### Borders
- Color: `oklch(0.92 0.02 258)` light mode (subtle blue-tinted grey), `oklch(1 0 0 / 12%)` dark mode (translucent white)
- Used on: cards, inputs, header, footer, buttons (outline variant)
- Border width: 1px throughout

### Animations
- **Library**: Framer Motion
- Theme toggle: `duration: 0.2, ease: 'easeInOut'` — sliding pill animation
- CSS transitions: `transition-all` on buttons, `transition-opacity` on icons
- No bounce — smooth and clinical easeInOut transitions throughout
- No page transitions in base template

### Hover / Press States
- Buttons: `hover:bg-primary/90` (10% opacity reduction) — color darkens subtly
- Outline buttons: `hover:bg-accent` (light blue-grey fill)
- Ghost buttons: `hover:bg-accent/50` in dark mode
- Links: `hover:underline` with `underline-offset-4`
- No scale transforms on press

### Iconography
- **Library**: Lucide React (stroke icons, 1.5px stroke weight)
- Icons sized at `size-4` (16px) inline, `size-4` in buttons
- Sun + Moon icons used in theme toggle
- No emoji, no unicode icon characters, no icon fonts
- No custom SVG illustrations in the base template

### Cards
- `rounded-xl` corners, `border`, `shadow-sm`, `bg-card`
- Padding: `py-6 px-6`
- Gap between header/content: `gap-6`
- Cards are clean white (light) / dark grey (dark) — no colored borders or accents on the card itself

### Use of Transparency & Blur
- Transparency used for: border colors in dark mode (`/ 12%`, `/ 15%`), hover state overlays (`/90`, `/80`, `/50`)
- No backdrop blur in base template

### Imagery
- NUH logos provided in light and dark variants (`nuh-logo.png`, `nuh-logo-dark.png`)
- No photography or illustrations in base template
- Logo: full-color on light mode, inverted/adapted for dark mode

---

## ICONOGRAPHY

- **Icon system**: Lucide React (`lucide-react` npm package), CDN also available at `https://unpkg.com/lucide-react`
- **Style**: Outlined / stroke icons, consistent 1.5px stroke weight, rounded linecaps
- **Usage**: Inline with text, 16px default size (`size-4`), 20px in larger contexts
- **Emoji**: Not used in any UI
- **Unicode chars**: Not used as icons
- **Custom SVGs**: Not present in base template; Next.js default SVGs (`file.svg`, `globe.svg`, `window.svg`) are generic placeholders

---

## FILE INDEX

```
README.md                    — This file; design system overview
SKILL.md                     — Agent skill definition
colors_and_type.css          — CSS custom properties (tokens)
assets/
  nuh-logo.png               — NUH logo (light mode)
  nuh-logo-dark.png          — NUH logo (dark mode)
preview/
  _base.css                  — Shared base CSS for all previews (v2 aesthetic)
  colors-brand.html          — Brand color swatches
  colors-semantic.html       — Semantic color tokens
  colors-dark.html           — Dark mode color palette
  type-scale.html            — Typography scale specimen
  type-fonts.html            — Font families
  spacing-radius.html        — Border radius tokens
  spacing-shadows.html       — Shadow / elevation system
  brand-logo.html            — Logo usage guidelines
  components-buttons.html    — Button variants
  components-badges.html     — Badge variants
  components-cards.html      — Card component
  components-toggle.html     — Mode toggle component
  components-inputs.html     — Form inputs
  components-alert.html      — Alert + Alert Dialog
  components-avatar.html     — Avatar sizes/variants/stacks
  components-breadcrumb.html — Breadcrumb + Pagination
  components-tabs.html       — Pill + underline tabs
  components-accordion.html  — Collapsible accordion
  components-controls.html   — Checkbox/radio/switch/toggle group
  components-select.html     — Select/combobox
  components-slider-progress.html — Slider + progress
  components-overlays.html   — Tooltip/popover/hover-card
  components-modals.html     — Dialog/sheet/drawer
  components-table.html      — Data table
  components-states.html     — Skeleton/spinner/empty
  components-toast.html      — Toast notifications
  components-navigation.html — Sidebar + nav menu
  components-calendar.html   — Calendar + date picker
  components-command.html    — Command menu
  components-extras.html     — Separator/Kbd/OTP/Field
ui_kits/
  website/
    README.md                — UI kit overview
    index.html               — Interactive NUH website prototype
    Header.jsx               — Site header component
    HeroSection.jsx          — Hero / landing section
    ColorPalette.jsx         — Brand color showcase
    ComponentShowcase.jsx    — Components grid
    Footer.jsx               — Site footer
```
